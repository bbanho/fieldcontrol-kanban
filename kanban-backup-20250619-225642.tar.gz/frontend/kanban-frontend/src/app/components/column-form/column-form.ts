import { Component } from '@angular/core';

@Component({
  selector: 'app-column-form',
  imports: [],
  templateUrl: './column-form.html',
  styleUrl: './column-form.scss'
})
export class ColumnForm {

}
