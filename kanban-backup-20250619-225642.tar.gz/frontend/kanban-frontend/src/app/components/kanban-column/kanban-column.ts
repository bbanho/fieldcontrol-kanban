import { Component } from '@angular/core';

@Component({
  selector: 'app-kanban-column',
  imports: [],
  templateUrl: './kanban-column.html',
  styleUrl: './kanban-column.scss'
})
export class KanbanColumn {

}
