import { Component } from '@angular/core';

@Component({
  selector: 'app-kanban-board',
  imports: [],
  templateUrl: './kanban-board.html',
  styleUrl: './kanban-board.scss'
})
export class KanbanBoard {

}
