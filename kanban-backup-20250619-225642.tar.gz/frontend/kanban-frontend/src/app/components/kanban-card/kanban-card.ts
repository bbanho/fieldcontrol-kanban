import { Component } from '@angular/core';

@Component({
  selector: 'app-kanban-card',
  imports: [],
  templateUrl: './kanban-card.html',
  styleUrl: './kanban-card.scss'
})
export class KanbanCard {

}
