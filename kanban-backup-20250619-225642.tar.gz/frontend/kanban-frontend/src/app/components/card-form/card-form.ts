import { Component } from '@angular/core';

@Component({
  selector: 'app-card-form',
  imports: [],
  templateUrl: './card-form.html',
  styleUrl: './card-form.scss'
})
export class CardForm {

}
